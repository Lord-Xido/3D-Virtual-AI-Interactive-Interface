
# CodexDreamLayer: Live 3D Symbolic Session

This project is a live symbolic WebGL visualization of the CodexDreamLayer engine using animated fractal logic.

- **Rendering:** Canvas/WebGL-based symbolic spiral
- **Engine:** CodexRenderSingularity vΩ++
- **Hosted:** Vercel
